package softwarehuset.management.app;

public class ProjectManager {
	private int isProjectManager;
	private String id;
	
	public ProjectManager(String id){
        this.id = id;
    }
	
	
}
